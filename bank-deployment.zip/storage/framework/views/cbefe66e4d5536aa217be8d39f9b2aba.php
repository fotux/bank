<?php $__env->startSection('content'); ?>
    <section>
        <main class="relative w-full h-screen ">

            <img class="h-full w-full " src="<?php echo e(asset('build/assets/bank-background.png')); ?>" alt="bank">

            <div class="absolute inset-0 flex justify-center items-center">
                <div class="flex-col text-center">

                    <h1 class="text-5xl font-bold text-white text-stroke mb-10">
                        The Bank You'll Want to Stay With
                    </h1>

                    <a href=" <?php echo e(route('bank.index')); ?>"
                        class="inline-block text-white text-xl border-black border-2 bg-secondary py-3 px-6 rounded-2xl font-bold  transform duration-500 hover:scale-105 shadow-md">Enter
                        Bank</a>

                </div>
            </div>
        </main>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karolisraginskis/Herd/bank/resources/views/index.blade.php ENDPATH**/ ?>