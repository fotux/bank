<?php $__env->startSection('content'); ?>
    <section style="background-image: url('<?php echo e(asset('build/assets/bg-gray.jpg')); ?>')" class="bg-cover min-h-screen">
        <main class="max-w-5xl mx-auto flex flex-col">

            <h1 class="text-3xl font-bold text-center my-20"> Create a Brand New Account Here!</h1>
            <form method="POST" action="<?php echo e(route('bank.store')); ?>" class="text-center ">
                <?php echo csrf_field(); ?>
                <section class="max-w-2xl mx-auto">
                    <div class="flex items-center gap-4 mt-5">
                        <label class="text-2xl text-primary font-serif w-56 text-left" for="name">Name</label>
                        <input
                            class="flex-1 bg-gray-300/20 py-2 px-5 rounded-sm text-gray-700 shadow-md border border-gray-200 focus:outline-none w-full"
                            type="text" name="name" placeholder="write name here">
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1 pl-3 text-right "><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="flex items-center gap-4 mt-5">
                        <label class="text-2xl text-primary font-serif w-56 text-left " for="surname">Surname</label>
                        <input
                            class="flex-1 bg-gray-300/20 py-2 px-5 rounded-sm text-gray-700 shadow-md border border-gray-200 focus:outline-none w-full "
                            type="text" name="surname" placeholder="write surname here">

                    </div>
                    <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1 text-right "><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="flex items-center gap-4 mt-5">

                        <label class="text-2xl text-primary font-serif w-56 text-left whitespace-nowrap "
                            for="name">Identity
                            Number</label>
                        <input
                            class="flex-1 bg-gray-300/20 py-2 px-5 rounded-sm text-gray-700 shadow-md border border-gray-200 focus:outline-none w-full"
                            type="text" name="identity_number" placeholder="write ID here">

                    </div>
                    <?php $__errorArgs = ['identity_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="pl-12 text-red-600 text-sm mt-1 text-right "><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <a href="<?php echo e(route('bank.index')); ?>"
                        class="mt-5 mr-10 items-center inline-block text-light text-center mb-10 text-xl bg-red-500 py-2 px-4 rounded-2xl font-bold border-white border-2 transform duration-500 hover:scale-101 shadow-md">Cancel
                    </a>

                    <button
                        class="mt-5 items-center inline-block text-light text-center mb-10 text-xl bg-secondary py-2 px-4 rounded-2xl font-bold border-black border-2 transform duration-500 hover:scale-101 shadow-md">Submit</button>

                </section>
            </form>

        </main>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karolisraginskis/Herd/bank/resources/views/bank/create.blade.php ENDPATH**/ ?>