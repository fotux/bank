<?php $__env->startSection('content'); ?>
    <section style="background-image: url('<?php echo e(asset('build/assets/bg-gray.jpg')); ?>')" class="bg-cover min-h-screen">
        <main class="max-w-5xl mx-auto flex flex-col">

            <h1 class="text-2xl font-bold text-center my-15">Grow your balance with ease.
                Make a deposit and experience banking where even saving feels magical.</h1>

            <div class="bg-secondary text-primary shadow-lg flex justify-between rounded-2xl p-5 border-black border-2 my-2">
                <div class="flex-col text-lg">
                    <h1>Name: <span class="text-light"> <?php echo e($account->name); ?> </span></h1>
                    <h1>Surname: <span class="text-light"><?php echo e($account->surname); ?> </span></h1>
                    <h1>Balance: <span class="text-light"><?php echo e($account->balance); ?> €</span></h1>
                    <h1>Credit Card Number: <span class="text-light"><?php echo e($account->account); ?> </span></h1>
                </div>

                <div class="flex items-start gap-3">

                    <form action="<?php echo e(route('bank.deposit.update', $account->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <a class="inline-block bg-red-500 text-light font-bold p-2 rounded-2xl transform duration-500 hover:scale-105 shadow-md border-2 mr-2"
                            href="<?php echo e(route('bank.index')); ?>">Cancel</a>
                        <input type="number" name="amount" step="0.01" min="0.01"
                            class="bg-white rounded-2xl py-2 mr-2 text-center text-secondary">
                        <button
                            class="inline-block bg-green-500 text-light font-bold p-2 rounded-2xl transform duration-500 hover:scale-105 shadow-md border-2">Deposit</button>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-sm mt-1 "><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>

                </div>

            </div>

        </main>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karolisraginskis/Herd/bank/resources/views/bank/deposit.blade.php ENDPATH**/ ?>