<?php $__env->startSection('content'); ?>
    <section style="background-image: url('<?php echo e(asset('build/assets/bg-gray.jpg')); ?>')" class="bg-cover min-h-screen">
        <main class="max-w-5xl mx-auto flex flex-col">

            <h1 class="text-2xl font-bold text-center my-15"> Welcome to NovaBank — Open accounts, manage finances,
                and experience
                banking
                where miracles happen!</h1>

            <a class="block text-light text-center mb-10 text-xl bg-secondary py-3 px-6 rounded-2xl font-bold border-black border-2 transform duration-500 hover:scale-101 shadow-md"
                href="">Create Account</a>

            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="bg-secondary text-primary shadow-lg flex justify-between rounded-2xl p-5 border-black border-2 my-2">
                    <div class="flex-col text-lg">
                        <h1>Name: <span class="text-light"> <?php echo e($account->name); ?> </span></h1>
                        <h1>Surname: <span class="text-light"><?php echo e($account->surname); ?> </span></h1>
                        <h1>Balance: <span class="text-light"><?php echo e($account->balance); ?> €</span></h1>
                        <h1>Credit Card Number: <span class="text-light"><?php echo e($account->account); ?> </span></h1>
                    </div>
                    <div class="flex items-center gap-3">
                        <form action="<?php echo e(route('bank.destroy', $account->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button
                                class="bg-red-500 text-light font-bold p-2 rounded-2xl transform duration-500 hover:scale-105 shadow-md border-2">Delete
                                Account</button>
                        </form>

                        <a class="block bg-green-500 text-light font-bold p-2 rounded-2xl transform duration-500 hover:scale-105 shadow-md border-2"
                            href="">Add
                            Money</a>
                        <a class="bg-blue-500 text-light font-bold p-2 rounded-2xl block transform duration-500 hover:scale-105 shadow-md border-2"
                            href="">Withdraw Money</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karolisraginskis/Herd/bank/resources/views/bank/bank.blade.php ENDPATH**/ ?>